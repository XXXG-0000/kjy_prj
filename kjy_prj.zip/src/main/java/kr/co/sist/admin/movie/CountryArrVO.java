package kr.co.sist.admin.movie;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CountryArrVO {
	private int movie_num;
	private String[] country_name_arr;
}
