package kr.co.sist.admin.movie;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SupervisionDomain {
	private int movie_num;
	private String s_name;
	private String image;
}
