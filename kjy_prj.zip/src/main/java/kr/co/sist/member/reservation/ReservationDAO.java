package kr.co.sist.member.reservation;

import java.util.List;

public interface ReservationDAO {
	
	public List<ReservationMovieDomain> selectAllMovie();
	
}
