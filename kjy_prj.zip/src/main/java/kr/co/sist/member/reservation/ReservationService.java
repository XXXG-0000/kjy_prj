package kr.co.sist.member.reservation;

import java.util.List;

public interface ReservationService {

	public List<ReservationMovieDomain> searchAllMovie();
	
}
