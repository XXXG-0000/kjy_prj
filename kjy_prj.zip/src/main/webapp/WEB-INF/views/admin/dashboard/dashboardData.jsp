<%@ page contentType="application/json;charset=UTF-8" language="java" info="" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page import="paik_prj.paik_prj.manager.paik.dashboard.DashboardDAO" %>
<%@ page import="org.json.simple.JSONObject" %>
<%@ page import="org.json.simple.JSONArray" %>
<% SERVICE에서 처리 %>
<%
    String type = request.getParameter("type"); // Controller에서 String 받기
    DashboardDAO dDAO = DashboardDAO.getInstance();
    JSONObject jsonResult = new JSONObject();

    try {
        if("sales".equals(type)) {
            int[] drinkSales = dDAO.selectDrinkSales();
            int[] dessertSales = dDAO.selectDessertSales();

            JSONArray drinkArray = new JSONArray();
            JSONArray dessertArray = new JSONArray();

            for(int i = 0; i < drinkSales.length; i++) {
                drinkArray.add(drinkSales[i]);
                dessertArray.add(dessertSales[i]);
            }

            jsonResult.put("drinkSales", drinkArray);
            jsonResult.put("dessertSales", dessertArray);

        } else if("members".equals(type)) {
	            int[] joins = dDAO.selectJoinCustomer();
	            int[] withdraws = dDAO.selectWithdrawCustomer();
	
	            JSONArray joinArray = new JSONArray();
	            JSONArray withdrawArray = new JSONArray();
	
	            for(int i = 0; i < joins.length; i++) {
	                joinArray.add(joins[i]);
	                withdrawArray.add(withdraws[i]);
	            }
	
	            jsonResult.put("joins", joinArray);
	            jsonResult.put("withdraws", withdrawArray);

        }

        out.print(jsonResult.toJSONString());

    } catch(Exception e) {
        jsonResult.put("error", e.getMessage());
        out.print(jsonResult.toJSONString());
    }
%>